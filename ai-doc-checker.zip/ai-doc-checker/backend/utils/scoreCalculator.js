/**
 * utils/scoreCalculator.js
 * Converts accumulated risk points from every analysis module into a
 * single 0-100 authenticity score and a Low/Medium/High risk label.
 */
function calculateScore(totalRiskPoints) {
  const clamped = Math.max(0, Math.min(100, totalRiskPoints));
  const authenticityScore = Math.round(100 - clamped);

  let riskLevel = 'Low';
  if (authenticityScore < 50) riskLevel = 'High';
  else if (authenticityScore < 80) riskLevel = 'Medium';

  return { authenticityScore, riskLevel };
}

module.exports = { calculateScore };
