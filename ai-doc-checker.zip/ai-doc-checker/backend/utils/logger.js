/**
 * Minimal structured logger so we have consistent, timestamped output
 * without pulling in a heavy dependency. Swap for winston/pino later if needed.
 */
const timestamp = () => new Date().toISOString();

module.exports = {
  info: (...args) => console.log(`[INFO] ${timestamp()} -`, ...args),
  warn: (...args) => console.warn(`[WARN] ${timestamp()} -`, ...args),
  error: (...args) => console.error(`[ERROR] ${timestamp()} -`, ...args),
};
