/**
 * services/tamperDetectionService.js
 * Heuristic tamper/manipulation detection for images and PDFs.
 *
 * This module is intentionally isolated so it can later be swapped for a
 * real computer-vision model (e.g. an ELA - Error Level Analysis - CNN,
 * or a hosted forensics API) without touching the rest of the pipeline.
 * See `analyzeWithRealModel()` for the extension point.
 */
const Jimp = require('jimp');
const logger = require('../utils/logger');

/**
 * Error Level Analysis (simplified): re-compresses the image at a known
 * JPEG quality and diffs it against the original. Regions that were pasted
 * or re-saved separately tend to show a different error level than the
 * rest of the image, surfacing as localized bright spots in the diff.
 */
async function runErrorLevelAnalysis(filePath) {
  try {
    const original = await Jimp.read(filePath);
    const resaved = original.clone();
    const buffer = await resaved.quality(90).getBufferAsync(Jimp.MIME_JPEG);
    const recompressed = await Jimp.read(buffer);

    const diff = Jimp.diff(original, recompressed, 0.1);
    const diffPercent = diff.percent * 100;

    return { diffPercent, suspiciousRegionDetected: diffPercent > 8 };
  } catch (err) {
    logger.error('Error level analysis failed:', err.message);
    return { diffPercent: 0, suspiciousRegionDetected: false, error: err.message };
  }
}

/**
 * Extension point: plug in a real trained model or third-party API here.
 * Keeping the same input/output contract means the rest of the app never
 * needs to change when you upgrade this from a heuristic to a real model.
 *
 * Example of how you might wire in a hosted vision model:
 *   const response = await fetch(process.env.AI_API_URL, { ... });
 */
// eslint-disable-next-line no-unused-vars
async function analyzeWithRealModel(filePath, fileType) {
  throw new Error('Real model integration not configured. Falling back to heuristic analysis.');
}

/**
 * Runs whichever tamper-detection strategy is available and normalizes
 * the result into findings + a risk contribution.
 */
async function detectTampering(filePath, fileType) {
  const findings = [];
  let riskPoints = 0;
  let elaResult = null;

  if (['jpg', 'jpeg', 'png'].includes(fileType)) {
    elaResult = await runErrorLevelAnalysis(filePath);
    if (elaResult.suspiciousRegionDetected) {
      findings.push({
        category: 'tampering',
        severity: 'high',
        title: 'Compression inconsistency detected',
        description: `Error level analysis found a ${elaResult.diffPercent.toFixed(1)}% divergence between original and re-compressed versions, suggesting parts of the image may have been edited or pasted in separately.`,
      });
      riskPoints += 35;
    } else {
      findings.push({
        category: 'tampering',
        severity: 'info',
        title: 'No compression anomalies found',
        description: 'Error level analysis did not detect localized editing artifacts.',
      });
    }
  } else if (fileType === 'pdf') {
    // Placeholder for PDF-specific tamper checks (e.g. inconsistent font
    // embedding, object cross-reference irregularities, incremental update
    // chains that don't match the visible content).
    findings.push({
      category: 'tampering',
      severity: 'info',
      title: 'Structural PDF check',
      description: 'Basic structural validation passed. Deep PDF forensics (incremental update analysis) is an extension point for future work.',
    });
  }

  return { findings, riskPoints: Math.min(riskPoints, 40), ela: elaResult };
}

module.exports = { detectTampering, analyzeWithRealModel };
