/**
 * services/signatureService.js
 * Digital signature verification for PDFs.
 *
 * A production implementation would parse the PDF's /ByteRange and
 * /Contents (PKCS#7 signature) using a library such as node-forge, verify
 * the signing certificate chain against a trusted root store, and check
 * that the signed byte range covers the entire (unmodified) document.
 * That cryptographic core is isolated in `verifySignatureCrypto()` so it
 * can be implemented without touching the calling pipeline.
 */
const fs = require('fs');
const logger = require('../utils/logger');

function documentContainsSignatureField(buffer) {
  const asString = buffer.toString('latin1');
  return asString.includes('/Sig') || asString.includes('/ByteRange');
}

/**
 * Extension point for real PKCS#7 / X.509 verification.
 */
// eslint-disable-next-line no-unused-vars
async function verifySignatureCrypto(filePath) {
  throw new Error('Cryptographic signature verification not yet implemented.');
}

async function verifySignature(filePath, fileType) {
  const findings = [];
  let riskPoints = 0;
  let hasSignatureField = false;

  if (fileType === 'pdf') {
    try {
      const buffer = fs.readFileSync(filePath);
      hasSignatureField = documentContainsSignatureField(buffer);
    } catch (err) {
      logger.error('Signature scan failed:', err.message);
    }
  }

  if (hasSignatureField) {
    findings.push({
      category: 'signature',
      severity: 'info',
      title: 'Digital signature field present',
      description: 'This document contains a digital signature field. Full cryptographic validation of the certificate chain is an extension point (see services/signatureService.js).',
    });
  } else {
    findings.push({
      category: 'signature',
      severity: 'info',
      title: 'No digital signature found',
      description: 'This document does not contain an embedded digital signature. This is common and not inherently suspicious.',
    });
  }

  return { findings, riskPoints, hasSignatureField, verified: false };
}

module.exports = { verifySignature, verifySignatureCrypto };
