/**
 * services/duplicateService.js
 * Duplicate / near-duplicate detection.
 *
 * Two layers:
 *  1. Exact duplicate - SHA-256 hash of the raw file bytes.
 *  2. Near-duplicate / similarity - a simple text-shingling + Jaccard
 *     similarity over extracted OCR/text content, so a re-scanned or
 *     re-saved copy of the same document is still caught even though its
 *     bytes differ. This is a lightweight stand-in for a proper
 *     perceptual-hash / embedding-similarity search over a vector index.
 */
const crypto = require('crypto');
const fs = require('fs');
const Document = require('../models/Document');

function hashFile(filePath) {
  const buffer = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function shingle(text, size = 5) {
  const words = text.toLowerCase().split(/\s+/).filter(Boolean);
  const shingles = new Set();
  for (let i = 0; i <= words.length - size; i += 1) {
    shingles.add(words.slice(i, i + size).join(' '));
  }
  return shingles;
}

function jaccardSimilarity(setA, setB) {
  if (setA.size === 0 || setB.size === 0) return 0;
  const intersection = new Set([...setA].filter((x) => setB.has(x)));
  const union = new Set([...setA, ...setB]);
  return intersection.size / union.size;
}

/**
 * Checks the current document against previously uploaded documents by the
 * same user (in a real deployment this would search across the whole
 * corpus, subject to privacy/authorization rules).
 */
async function checkDuplicates({ filePath, extractedText, userId, currentDocumentId }) {
  const findings = [];
  let riskPoints = 0;

  const fileHash = hashFile(filePath);

  const exactMatch = await Document.findOne({
    fileHash,
    user: userId,
    _id: { $ne: currentDocumentId },
  });

  if (exactMatch) {
    findings.push({
      category: 'duplicate',
      severity: 'medium',
      title: 'Exact duplicate found',
      description: `This file is byte-for-byte identical to a previously uploaded document ("${exactMatch.originalName}").`,
    });
    riskPoints += 15;
  } else if (extractedText && extractedText.length > 50) {
    const currentShingles = shingle(extractedText);
    const priorDocs = await Document.find({
      user: userId,
      _id: { $ne: currentDocumentId },
      extractedText: { $exists: true, $ne: '' },
    })
      .limit(25)
      .select('originalName extractedText');

    let bestMatch = { name: null, score: 0 };
    priorDocs.forEach((doc) => {
      const score = jaccardSimilarity(currentShingles, shingle(doc.extractedText));
      if (score > bestMatch.score) bestMatch = { name: doc.originalName, score };
    });

    if (bestMatch.score > 0.6) {
      findings.push({
        category: 'duplicate',
        severity: 'low',
        title: 'High content similarity detected',
        description: `This document's text content is ${Math.round(bestMatch.score * 100)}% similar to a previously uploaded document ("${bestMatch.name}"). This may indicate a re-scanned or re-saved copy.`,
      });
      riskPoints += 8;
    }
  }

  return { findings, riskPoints: Math.min(riskPoints, 20), fileHash };
}

module.exports = { checkDuplicates, hashFile };
