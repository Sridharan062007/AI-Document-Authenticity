/**
 * services/metadataService.js
 * Extracts document metadata (author, creation/modification dates, producing
 * software) from PDFs and images. DOCX metadata would be read from its
 * embedded core.xml in the same fashion - stubbed here for extensibility.
 */
const fs = require('fs');
const { PDFDocument } = require('pdf-lib');
const Jimp = require('jimp');
const logger = require('../utils/logger');

async function extractPdfMetadata(filePath) {
  const bytes = fs.readFileSync(filePath);
  const pdfDoc = await PDFDocument.load(bytes, { ignoreEncryption: true });

  return {
    author: pdfDoc.getAuthor() || null,
    createdDate: pdfDoc.getCreationDate() || null,
    modifiedDate: pdfDoc.getModificationDate() || null,
    software: pdfDoc.getProducer() || pdfDoc.getCreator() || null,
    pageCount: pdfDoc.getPageCount(),
    raw: {
      title: pdfDoc.getTitle() || null,
      subject: pdfDoc.getSubject() || null,
      keywords: pdfDoc.getKeywords() || null,
    },
  };
}

async function extractImageMetadata(filePath) {
  const image = await Jimp.read(filePath);
  const exif = image._exif && image._exif.tags ? image._exif.tags : {};

  return {
    author: exif.Artist || null,
    createdDate: exif.DateTimeOriginal ? new Date(exif.DateTimeOriginal) : null,
    modifiedDate: exif.ModifyDate ? new Date(exif.ModifyDate) : null,
    software: exif.Software || null,
    pageCount: 1,
    raw: {
      width: image.bitmap.width,
      height: image.bitmap.height,
      exif,
    },
  };
}

/**
 * Placeholder for DOCX metadata - a real implementation would unzip the
 * .docx (it's a zip archive) and parse docProps/core.xml with an XML parser.
 */
async function extractDocxMetadata(filePath) {
  logger.warn('DOCX metadata extraction is a stub - returning defaults. Wire up a zip/xml parser here.');
  return {
    author: null,
    createdDate: null,
    modifiedDate: null,
    software: null,
    pageCount: null,
    raw: { note: 'DOCX metadata extraction not yet implemented' },
  };
}

/**
 * Main entry point - dispatches based on file type.
 * @param {string} filePath - absolute path on disk
 * @param {string} fileType - 'pdf' | 'docx' | 'jpg' | 'jpeg' | 'png'
 */
async function extractMetadata(filePath, fileType) {
  try {
    if (fileType === 'pdf') return await extractPdfMetadata(filePath);
    if (['jpg', 'jpeg', 'png'].includes(fileType)) return await extractImageMetadata(filePath);
    if (fileType === 'docx') return await extractDocxMetadata(filePath);
    return { author: null, createdDate: null, modifiedDate: null, software: null, pageCount: null, raw: {} };
  } catch (err) {
    logger.error('Metadata extraction failed:', err.message);
    return { author: null, createdDate: null, modifiedDate: null, software: null, pageCount: null, raw: { error: err.message } };
  }
}

/**
 * Analyzes extracted metadata for red flags (missing fields, suspicious
 * editing-software fingerprints, creation/modification date mismatches).
 */
function analyzeMetadata(metadata) {
  const findings = [];
  let riskPoints = 0;

  if (!metadata.createdDate) {
    findings.push({
      category: 'metadata',
      severity: 'low',
      title: 'Missing creation date',
      description: 'The document does not expose a creation timestamp, which can happen with stripped or regenerated metadata.',
    });
    riskPoints += 5;
  }

  if (metadata.createdDate && metadata.modifiedDate) {
    const created = new Date(metadata.createdDate).getTime();
    const modified = new Date(metadata.modifiedDate).getTime();
    if (modified - created > 1000 * 60 * 60 * 24 * 365) {
      findings.push({
        category: 'metadata',
        severity: 'medium',
        title: 'Large gap between creation and modification',
        description: 'The document was modified more than a year after it was created, which may indicate later editing.',
      });
      riskPoints += 15;
    }
  }

  const suspiciousTools = ['photoshop', 'gimp', 'illustrator', 'pdf editor', 'ilovepdf', 'smallpdf'];
  if (metadata.software && suspiciousTools.some((tool) => metadata.software.toLowerCase().includes(tool))) {
    findings.push({
      category: 'metadata',
      severity: 'high',
      title: 'Editing software fingerprint detected',
      description: `The producing software field references "${metadata.software}", commonly used for image/PDF editing rather than original authoring.`,
    });
    riskPoints += 30;
  }

  if (!metadata.author) {
    findings.push({
      category: 'metadata',
      severity: 'info',
      title: 'No author information',
      description: 'The document does not declare an author in its metadata.',
    });
    riskPoints += 3;
  }

  return { findings, riskPoints: Math.min(riskPoints, 50) };
}

module.exports = { extractMetadata, analyzeMetadata };
