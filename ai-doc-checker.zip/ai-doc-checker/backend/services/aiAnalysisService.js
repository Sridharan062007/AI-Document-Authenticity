/**
 * services/aiAnalysisService.js
 * -----------------------------------------------------------------------
 * ORCHESTRATOR - this is the single place that ties every analysis module
 * together into one authenticity report. Each module below is independent
 * and swappable, which is what makes it straightforward to replace the
 * current heuristics with real hosted AI models later:
 *
 *   metadataService        -> replace with a metadata-forensics model/API
 *   ocrService              -> already usable as-is (Tesseract.js); can be
 *                              swapped for a hosted OCR API for accuracy
 *   tamperDetectionService  -> replace runErrorLevelAnalysis() /
 *                              analyzeWithRealModel() with a real
 *                              vision model (e.g. a fine-tuned CNN or a
 *                              hosted forensics endpoint)
 *   signatureService        -> replace verifySignatureCrypto() with real
 *                              PKCS#7 / X.509 chain validation
 *   qrService                -> add issuer cross-checking APIs per document type
 *   duplicateService         -> replace shingling with vector embeddings +
 *                              a similarity index (e.g. pgvector, Pinecone)
 *
 * To integrate a real generative-AI reasoning layer (e.g. summarizing
 * findings in natural language, or asking a model to holistically judge
 * authenticity), see `generateAiSummary()` at the bottom of this file.
 * -----------------------------------------------------------------------
 */
const metadataService = require('./metadataService');
const ocrService = require('./ocrService');
const tamperDetectionService = require('./tamperDetectionService');
const signatureService = require('./signatureService');
const qrService = require('./qrService');
const duplicateService = require('./duplicateService');
const { calculateScore } = require('../utils/scoreCalculator');
const logger = require('../utils/logger');

/**
 * Runs the full authenticity analysis pipeline for a single document.
 * @param {Object} params
 * @param {string} params.filePath - absolute path to the stored file
 * @param {string} params.fileType - 'pdf' | 'docx' | 'jpg' | 'jpeg' | 'png'
 * @param {string} params.userId - owning user's id (for duplicate lookups)
 * @param {string} params.documentId - the Document document's _id
 * @returns {Promise<Object>} a full report payload ready to persist
 */
async function runFullAnalysis({ filePath, fileType, userId, documentId }) {
  logger.info(`Starting analysis pipeline for document ${documentId} (${fileType})`);

  // Run independent modules concurrently where they don't depend on each other
  const [metadataRaw, ocrRaw, tamperRaw, signatureRaw, qrRaw] = await Promise.all([
    metadataService.extractMetadata(filePath, fileType),
    ocrService.extractText(filePath, fileType),
    tamperDetectionService.detectTampering(filePath, fileType),
    signatureService.verifySignature(filePath, fileType),
    qrService.scanForQrCode(filePath, fileType),
  ]);

  const metadataAnalysis = metadataService.analyzeMetadata(metadataRaw);
  const ocrAnalysis = ocrService.analyzeOcrText(ocrRaw);

  // Duplicate detection depends on OCR text, so it runs after
  const duplicateAnalysis = await duplicateService.checkDuplicates({
    filePath,
    extractedText: ocrRaw.text,
    userId,
    currentDocumentId: documentId,
  });

  const allFindings = [
    ...metadataAnalysis.findings,
    ...ocrAnalysis.findings,
    ...tamperRaw.findings,
    ...signatureRaw.findings,
    ...qrRaw.findings,
    ...duplicateAnalysis.findings,
  ];

  const totalRiskPoints =
    metadataAnalysis.riskPoints +
    ocrAnalysis.riskPoints +
    tamperRaw.riskPoints +
    signatureRaw.riskPoints +
    duplicateAnalysis.riskPoints;

  const { authenticityScore, riskLevel } = calculateScore(totalRiskPoints);

  const suspiciousSections = allFindings
    .filter((f) => f.severity === 'high' || f.severity === 'medium')
    .map((f) => ({ page: 1, excerpt: f.title, reason: f.description }));

  const summary = generateAiSummary({ authenticityScore, riskLevel, findings: allFindings });

  return {
    metadataRaw,
    extractedText: ocrRaw.text,
    report: {
      authenticityScore,
      riskLevel,
      summary,
      findings: allFindings,
      suspiciousSections,
      modules: {
        metadataAnalysis: { ...metadataRaw, riskPoints: metadataAnalysis.riskPoints },
        ocrAnalysis,
        tamperDetection: tamperRaw,
        signatureVerification: signatureRaw,
        qrBarcodeVerification: qrRaw,
        duplicateDetection: duplicateAnalysis,
      },
      aiProvider: 'internal-heuristic-v1',
    },
  };
}

/**
 * Produces a short natural-language summary of the findings.
 *
 * EXTENSION POINT: replace this rule-based summary with a call to a real
 * LLM (Anthropic/OpenAI/etc). Example shape:
 *
 *   const res = await fetch(process.env.AI_API_URL, {
 *     method: 'POST',
 *     headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.AI_API_KEY}` },
 *     body: JSON.stringify({
 *       model: 'claude-sonnet-4-6',
 *       max_tokens: 300,
 *       messages: [{ role: 'user', content: buildSummaryPrompt({ authenticityScore, riskLevel, findings }) }],
 *     }),
 *   });
 *   const data = await res.json();
 *   return data.content[0].text;
 */
function generateAiSummary({ authenticityScore, riskLevel, findings }) {
  const highSeverity = findings.filter((f) => f.severity === 'high');
  const mediumSeverity = findings.filter((f) => f.severity === 'medium');

  if (riskLevel === 'Low') {
    return `This document scored ${authenticityScore}/100 and shows no significant signs of manipulation. Metadata, OCR content, and structural checks are all consistent with an authentic, unedited document.`;
  }

  if (riskLevel === 'Medium') {
    return `This document scored ${authenticityScore}/100. ${mediumSeverity.length} moderate finding(s) were identified, including "${mediumSeverity[0]?.title || 'irregularities'}". Manual review is recommended before relying on this document.`;
  }

  return `This document scored ${authenticityScore}/100, indicating a high likelihood of manipulation. ${highSeverity.length} high-severity finding(s) were detected, most notably "${highSeverity[0]?.title || 'structural anomalies'}". Treat this document as unverified.`;
}

module.exports = { runFullAnalysis, generateAiSummary };
