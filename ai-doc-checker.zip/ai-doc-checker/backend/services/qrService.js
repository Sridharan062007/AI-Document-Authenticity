/**
 * services/qrService.js
 * Detects and decodes QR codes / barcodes embedded in a document image so
 * their payload can be cross-checked against an issuing authority's system
 * (e.g. government ID portals, university degree verification, etc).
 * Actual issuer cross-checking is left as an extension point since it is
 * specific to each document type and requires a third-party API/registry.
 */
const Jimp = require('jimp');
const QrCode = require('qrcode-reader');
const logger = require('../utils/logger');

async function scanForQrCode(filePath, fileType) {
  const findings = [];

  if (!['jpg', 'jpeg', 'png'].includes(fileType)) {
    return { findings, qrPayload: null, detected: false };
  }

  try {
    const image = await Jimp.read(filePath);
    const qr = new QrCode();

    const payload = await new Promise((resolve) => {
      qr.callback = (err, value) => resolve(err ? null : value && value.result);
      qr.decode(image.bitmap);
    });

    if (payload) {
      findings.push({
        category: 'qr',
        severity: 'info',
        title: 'QR code detected',
        description: `A QR code was found in the document. Decoded payload preview: "${String(payload).slice(0, 80)}". Cross-referencing against an issuing authority requires connecting a verification API for that document type.`,
      });
      return { findings, qrPayload: payload, detected: true };
    }

    return {
      findings: [
        {
          category: 'qr',
          severity: 'info',
          title: 'No QR or barcode found',
          description: 'No scannable QR/barcode was detected in this document.',
        },
      ],
      qrPayload: null,
      detected: false,
    };
  } catch (err) {
    logger.error('QR scan failed:', err.message);
    return { findings: [], qrPayload: null, detected: false, error: err.message };
  }
}

module.exports = { scanForQrCode };
