/**
 * services/ocrService.js
 * Runs OCR against image-based documents (and rasterized PDF pages) using
 * Tesseract.js, then flags text-layer anomalies that often correlate with
 * tampering (inconsistent fonts/spacing artifacts, broken words, etc.)
 */
const Tesseract = require('tesseract.js');
const pdfParse = require('pdf-parse');
const fs = require('fs');
const logger = require('../utils/logger');

/**
 * OCRs an image file and returns the recognized text plus a confidence score.
 */
async function ocrImage(filePath) {
  const { data } = await Tesseract.recognize(filePath, 'eng', {
    logger: () => {}, // silence verbose progress logs on the server
  });
  return { text: data.text || '', confidence: data.confidence || 0 };
}

/**
 * Extracts the embedded text layer from a PDF. If the PDF has little or no
 * text layer, it is likely a scanned document - callers can decide whether
 * to fall back to rasterizing pages and running OCR (left as an extension
 * point since it requires a PDF-to-image step such as pdf-poppler or pdf.js).
 */
async function extractPdfText(filePath) {
  try {
    const buffer = fs.readFileSync(filePath);
    const parsed = await pdfParse(buffer);
    return { text: parsed.text || '', confidence: parsed.text && parsed.text.length > 20 ? 95 : 20 };
  } catch (err) {
    logger.error('PDF text extraction failed:', err.message);
    return { text: '', confidence: 0 };
  }
}

/**
 * Main dispatcher used by the analysis pipeline.
 */
async function extractText(filePath, fileType) {
  if (['jpg', 'jpeg', 'png'].includes(fileType)) return ocrImage(filePath);
  if (fileType === 'pdf') return extractPdfText(filePath);
  // DOCX text extraction would use mammoth.js or a zip/xml parser - extension point.
  return { text: '', confidence: 0 };
}

/**
 * Looks for lightweight linguistic/structural anomalies in extracted text
 * that can suggest tampering (e.g. inconsistent spacing, broken words,
 * repeated control characters left behind by copy-paste edits).
 */
function analyzeOcrText(ocrResult) {
  const findings = [];
  let riskPoints = 0;
  const { text, confidence } = ocrResult;

  if (confidence < 50 && text.length > 0) {
    findings.push({
      category: 'ocr',
      severity: 'medium',
      title: 'Low OCR confidence',
      description: `Text recognition confidence was only ${Math.round(confidence)}%, which can indicate a low-quality scan or an image that was altered after scanning.`,
    });
    riskPoints += 10;
  }

  const doubleSpaceMatches = (text.match(/ {3,}/g) || []).length;
  if (doubleSpaceMatches > 5) {
    findings.push({
      category: 'ocr',
      severity: 'low',
      title: 'Irregular spacing patterns',
      description: 'Multiple sections contain unusually large gaps between words, which can occur when text is deleted or replaced.',
    });
    riskPoints += 8;
  }

  if (text.length < 20) {
    findings.push({
      category: 'ocr',
      severity: 'info',
      title: 'Minimal extractable text',
      description: 'Very little text could be extracted from this document, limiting the depth of content-based analysis.',
    });
    riskPoints += 2;
  }

  return { findings, riskPoints: Math.min(riskPoints, 30), textLength: text.length, confidence };
}

module.exports = { extractText, analyzeOcrText };
