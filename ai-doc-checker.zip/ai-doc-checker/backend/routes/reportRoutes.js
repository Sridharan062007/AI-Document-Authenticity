const express = require('express');
const { listReports, getReport, getStats, downloadReportPdf } = require('../controllers/reportController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect);
router.get('/', listReports);
router.get('/stats/summary', getStats);
router.get('/:id', getReport);
router.get('/:id/pdf', downloadReportPdf);

module.exports = router;
