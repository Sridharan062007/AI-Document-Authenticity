const express = require('express');
const { uploadDocument, analyzeDocument, listDocuments } = require('../controllers/documentController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

router.use(protect);
router.get('/', listDocuments);
router.post('/upload', upload.single('file'), uploadDocument);
router.post('/:id/analyze', analyzeDocument);

module.exports = router;
