/**
 * models/Report.js
 * The verification report generated after a document passes through the
 * analysis pipeline. This is the primary object shown on the dashboard/history.
 */
const mongoose = require('mongoose');

const findingSchema = new mongoose.Schema(
  {
    category: {
      type: String,
      enum: ['metadata', 'ocr', 'tampering', 'signature', 'qr', 'duplicate'],
      required: true,
    },
    severity: { type: String, enum: ['info', 'low', 'medium', 'high'], default: 'info' },
    title: { type: String, required: true },
    description: { type: String, required: true },
  },
  { _id: false }
);

const reportSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    document: { type: mongoose.Schema.Types.ObjectId, ref: 'Document', required: true },
    fileName: { type: String, required: true },
    authenticityScore: { type: Number, min: 0, max: 100, required: true },
    riskLevel: { type: String, enum: ['Low', 'Medium', 'High'], required: true },
    summary: { type: String, required: true },
    findings: [findingSchema],
    suspiciousSections: [
      {
        page: { type: Number, default: 1 },
        excerpt: { type: String },
        reason: { type: String },
      },
    ],
    modules: {
      metadataAnalysis: { type: mongoose.Schema.Types.Mixed, default: {} },
      ocrAnalysis: { type: mongoose.Schema.Types.Mixed, default: {} },
      tamperDetection: { type: mongoose.Schema.Types.Mixed, default: {} },
      signatureVerification: { type: mongoose.Schema.Types.Mixed, default: {} },
      qrBarcodeVerification: { type: mongoose.Schema.Types.Mixed, default: {} },
      duplicateDetection: { type: mongoose.Schema.Types.Mixed, default: {} },
    },
    aiProvider: { type: String, default: 'internal-heuristic-v1' },
    reportPdfPath: { type: String, default: null },
  },
  { timestamps: true }
);

reportSchema.index({ fileName: 'text', summary: 'text' });

module.exports = mongoose.model('Report', reportSchema);
