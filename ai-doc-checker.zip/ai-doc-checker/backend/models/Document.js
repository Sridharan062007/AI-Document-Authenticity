/**
 * models/Document.js
 * Represents an uploaded document and the raw extracted data used for analysis.
 */
const mongoose = require('mongoose');

const documentSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    originalName: { type: String, required: true },
    storedFileName: { type: String, required: true },
    filePath: { type: String, required: true },
    mimeType: { type: String, required: true },
    fileSizeBytes: { type: Number, required: true },
    fileType: { type: String, enum: ['pdf', 'docx', 'jpg', 'jpeg', 'png'], required: true },
    status: {
      type: String,
      enum: ['uploaded', 'processing', 'analyzed', 'failed'],
      default: 'uploaded',
    },
    extractedText: { type: String, default: '' },
    metadata: {
      author: { type: String, default: null },
      createdDate: { type: Date, default: null },
      modifiedDate: { type: Date, default: null },
      software: { type: String, default: null },
      pageCount: { type: Number, default: null },
      raw: { type: mongoose.Schema.Types.Mixed, default: {} },
    },
    fileHash: { type: String, default: null }, // SHA-256, used for duplicate detection
  },
  { timestamps: true }
);

module.exports = mongoose.model('Document', documentSchema);
