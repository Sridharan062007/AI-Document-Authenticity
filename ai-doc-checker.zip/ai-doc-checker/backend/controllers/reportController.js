/**
 * controllers/reportController.js
 * Report retrieval, search, and PDF export.
 */
const path = require('path');
const fs = require('fs');
const asyncHandler = require('express-async-handler');
const Report = require('../models/Report');
const { generateReportPdf } = require('../services/pdfReportService');

// @desc   List / search the current user's reports
// @route  GET /api/reports?search=&risk=&page=&limit=
const listReports = asyncHandler(async (req, res) => {
  const { search = '', risk, page = 1, limit = 12 } = req.query;

  const query = { user: req.user._id };
  if (risk && ['Low', 'Medium', 'High'].includes(risk)) query.riskLevel = risk;
  if (search) query.fileName = { $regex: search, $options: 'i' };

  const skip = (Number(page) - 1) * Number(limit);

  const [reports, total] = await Promise.all([
    Report.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Report.countDocuments(query),
  ]);

  res.json({ success: true, reports, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
});

// @desc   Get a single report by id
// @route  GET /api/reports/:id
const getReport = asyncHandler(async (req, res) => {
  const report = await Report.findOne({ _id: req.params.id, user: req.user._id });
  if (!report) {
    res.status(404);
    throw new Error('Report not found');
  }
  res.json({ success: true, report });
});

// @desc   Dashboard summary stats
// @route  GET /api/reports/stats/summary
const getStats = asyncHandler(async (req, res) => {
  const reports = await Report.find({ user: req.user._id }).select('authenticityScore riskLevel createdAt');

  const total = reports.length;
  const avgScore = total ? Math.round(reports.reduce((sum, r) => sum + r.authenticityScore, 0) / total) : 0;
  const riskCounts = { Low: 0, Medium: 0, High: 0 };
  reports.forEach((r) => { riskCounts[r.riskLevel] = (riskCounts[r.riskLevel] || 0) + 1; });

  const trend = reports
    .slice()
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
    .slice(-10)
    .map((r) => ({ date: r.createdAt, score: r.authenticityScore }));

  res.json({ success: true, stats: { total, avgScore, riskCounts, trend } });
});

// @desc   Download a report as PDF (generates on first request, then caches)
// @route  GET /api/reports/:id/pdf
const downloadReportPdf = asyncHandler(async (req, res) => {
  const report = await Report.findOne({ _id: req.params.id, user: req.user._id });
  if (!report) {
    res.status(404);
    throw new Error('Report not found');
  }

  const outputDir = path.join(__dirname, '..', 'uploads', 'reports');
  if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

  let pdfPath = report.reportPdfPath;
  if (!pdfPath || !fs.existsSync(pdfPath)) {
    pdfPath = await generateReportPdf(report, outputDir);
    report.reportPdfPath = pdfPath;
    await report.save();
  }

  res.download(pdfPath, `authenticity-report-${report._id}.pdf`);
});

module.exports = { listReports, getReport, getStats, downloadReportPdf };
