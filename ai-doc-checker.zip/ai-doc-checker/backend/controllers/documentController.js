/**
 * controllers/documentController.js
 * Handles document upload and triggers the analysis pipeline.
 */
const path = require('path');
const asyncHandler = require('express-async-handler');
const Document = require('../models/Document');
const Report = require('../models/Report');
const aiAnalysisService = require('../services/aiAnalysisService');
const { generateReportPdf } = require('../services/pdfReportService');
const logger = require('../utils/logger');

function getFileTypeFromMime(mimeType, originalName) {
  const map = {
    'application/pdf': 'pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
    'image/jpeg': 'jpg',
    'image/png': 'png',
  };
  if (map[mimeType]) return map[mimeType];
  const ext = path.extname(originalName).replace('.', '').toLowerCase();
  return ['pdf', 'docx', 'jpg', 'jpeg', 'png'].includes(ext) ? ext : 'pdf';
}

// @desc   Upload a document (does not yet analyze it)
// @route  POST /api/documents/upload
const uploadDocument = asyncHandler(async (req, res) => {
  if (!req.file) {
    res.status(400);
    throw new Error('No file uploaded');
  }

  const fileType = getFileTypeFromMime(req.file.mimetype, req.file.originalname);

  const document = await Document.create({
    user: req.user._id,
    originalName: req.file.originalname,
    storedFileName: req.file.filename,
    filePath: req.file.path,
    mimeType: req.file.mimetype,
    fileSizeBytes: req.file.size,
    fileType,
    status: 'uploaded',
  });

  res.status(201).json({
    success: true,
    document: {
      id: document._id,
      originalName: document.originalName,
      fileType: document.fileType,
      fileSizeBytes: document.fileSizeBytes,
      status: document.status,
      createdAt: document.createdAt,
    },
  });
});

// @desc   Run the authenticity analysis pipeline on an uploaded document
// @route  POST /api/documents/:id/analyze
const analyzeDocument = asyncHandler(async (req, res) => {
  const document = await Document.findOne({ _id: req.params.id, user: req.user._id });
  if (!document) {
    res.status(404);
    throw new Error('Document not found');
  }

  document.status = 'processing';
  await document.save();

  try {
    const { metadataRaw, extractedText, report } = await aiAnalysisService.runFullAnalysis({
      filePath: document.filePath,
      fileType: document.fileType,
      userId: req.user._id,
      documentId: document._id,
    });

    document.metadata = {
      author: metadataRaw.author,
      createdDate: metadataRaw.createdDate,
      modifiedDate: metadataRaw.modifiedDate,
      software: metadataRaw.software,
      pageCount: metadataRaw.pageCount,
      raw: metadataRaw.raw,
    };
    document.extractedText = extractedText.slice(0, 20000); // guard against huge payloads
    document.fileHash = report.modules.duplicateDetection.fileHash;
    document.status = 'analyzed';
    await document.save();

    const savedReport = await Report.create({
      user: req.user._id,
      document: document._id,
      fileName: document.originalName,
      ...report,
    });

    res.json({ success: true, report: savedReport });
  } catch (err) {
    document.status = 'failed';
    await document.save();
    logger.error('Analysis pipeline failed:', err.message);
    res.status(500);
    throw new Error('Document analysis failed. Please try again.');
  }
});

// @desc   List the current user's documents
// @route  GET /api/documents
const listDocuments = asyncHandler(async (req, res) => {
  const documents = await Document.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(100);
  res.json({ success: true, documents });
});

module.exports = { uploadDocument, analyzeDocument, listDocuments };
