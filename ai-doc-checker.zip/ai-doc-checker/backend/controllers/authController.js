/**
 * controllers/authController.js
 * Handles signup, login, and fetching/updating the current user's profile.
 */
const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const User = require('../models/User');

const AVATAR_COLORS = ['#0F9D6B', '#0EA5A0', '#6366F1', '#D97706', '#DC2626', '#0284C7'];

function signToken(userId) {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

function sanitizeUser(user) {
  return {
    id: user._id,
    name: user.name,
    email: user.email,
    organization: user.organization,
    role: user.role,
    avatarColor: user.avatarColor,
    preferences: user.preferences,
    createdAt: user.createdAt,
  };
}

// @desc   Register a new user
// @route  POST /api/auth/signup
const signup = asyncHandler(async (req, res) => {
  const { name, email, password, organization } = req.body;

  if (!name || !email || !password) {
    res.status(400);
    throw new Error('Name, email, and password are required');
  }

  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) {
    res.status(409);
    throw new Error('An account with this email already exists');
  }

  const avatarColor = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

  const user = await User.create({ name, email, password, organization, avatarColor });
  const token = signToken(user._id);

  res.status(201).json({ success: true, token, user: sanitizeUser(user) });
});

// @desc   Authenticate user & return token
// @route  POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400);
    throw new Error('Email and password are required');
  }

  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user || !(await user.comparePassword(password))) {
    res.status(401);
    throw new Error('Invalid email or password');
  }

  const token = signToken(user._id);
  res.json({ success: true, token, user: sanitizeUser(user) });
});

// @desc   Get current logged in user
// @route  GET /api/auth/me
const getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, user: sanitizeUser(req.user) });
});

// @desc   Update profile / preferences
// @route  PUT /api/auth/me
const updateMe = asyncHandler(async (req, res) => {
  const { name, organization, preferences } = req.body;

  if (name !== undefined) req.user.name = name;
  if (organization !== undefined) req.user.organization = organization;
  if (preferences?.theme) req.user.preferences.theme = preferences.theme;
  if (preferences?.emailAlerts !== undefined) req.user.preferences.emailAlerts = preferences.emailAlerts;

  await req.user.save();
  res.json({ success: true, user: sanitizeUser(req.user) });
});

module.exports = { signup, login, getMe, updateMe };
