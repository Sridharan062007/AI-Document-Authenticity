/**
 * Design tokens for the "Verification Lab" visual identity:
 * - Ink navy + paper backgrounds evoke official/legal documents.
 * - A single verified-green accent stands in for the "authentic" seal;
 *   amber/red are reserved strictly for medium/high risk states so they
 *   keep diagnostic meaning instead of becoming decoration.
 * - Fraunces (serif) carries headline personality like a certificate
 *   letterhead; Inter handles UI; JetBrains Mono renders hashes/metadata.
 */
/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0F172A',
          light: '#1E293B',
        },
        paper: {
          DEFAULT: '#FAF9F6',
          dim: '#F1EFE9',
        },
        verified: {
          DEFAULT: '#0F9D6B',
          light: '#E4F5EE',
          dark: '#0B7A54',
        },
        accent: {
          DEFAULT: '#0EA5A0',
          light: '#E0F5F4',
        },
        risk: {
          low: '#0F9D6B',
          medium: '#D97706',
          high: '#DC2626',
        },
      },
      fontFamily: {
        display: ['"Fraunces"', 'ui-serif', 'Georgia', 'serif'],
        sans: ['"Inter"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 24px -8px rgba(15, 23, 42, 0.10)',
        'card-hover': '0 4px 12px rgba(15, 23, 42, 0.08), 0 16px 40px -12px rgba(15, 23, 42, 0.16)',
        seal: '0 0 0 4px rgba(15, 157, 107, 0.12)',
      },
      keyframes: {
        scan: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
        'seal-pulse': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(15, 157, 107, 0.35)' },
          '50%': { boxShadow: '0 0 0 12px rgba(15, 157, 107, 0)' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'spin-slow': {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
      },
      animation: {
        scan: 'scan 1.8s ease-in-out infinite',
        'seal-pulse': 'seal-pulse 2s ease-out infinite',
        'fade-up': 'fade-up 0.5s ease-out both',
        'spin-slow': 'spin-slow 6s linear infinite',
      },
    },
  },
  plugins: [],
};
