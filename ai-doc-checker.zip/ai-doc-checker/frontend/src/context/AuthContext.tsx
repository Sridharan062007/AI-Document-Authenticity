/**
 * context/AuthContext.tsx
 * Holds the authenticated user + token, exposes login/signup/logout.
 */
import React, { createContext, useCallback, useEffect, useState } from 'react';
import api from '../services/api';
import type { User } from '../types';

interface AuthContextValue {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string, organization?: string) => Promise<void>;
  logout: () => void;
  updateUser: (user: User) => void;
}

export const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('veridoc_token'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('veridoc_user');
    if (stored) setUser(JSON.parse(stored));
    setLoading(false);
  }, []);

  const persist = (nextToken: string, nextUser: User) => {
    localStorage.setItem('veridoc_token', nextToken);
    localStorage.setItem('veridoc_user', JSON.stringify(nextUser));
    setToken(nextToken);
    setUser(nextUser);
  };

  const login = useCallback(async (email: string, password: string) => {
    const { data } = await api.post('/auth/login', { email, password });
    persist(data.token, data.user);
  }, []);

  const signup = useCallback(async (name: string, email: string, password: string, organization?: string) => {
    const { data } = await api.post('/auth/signup', { name, email, password, organization });
    persist(data.token, data.user);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('veridoc_token');
    localStorage.removeItem('veridoc_user');
    setToken(null);
    setUser(null);
  }, []);

  const updateUser = useCallback((nextUser: User) => {
    localStorage.setItem('veridoc_user', JSON.stringify(nextUser));
    setUser(nextUser);
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, loading, login, signup, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}
