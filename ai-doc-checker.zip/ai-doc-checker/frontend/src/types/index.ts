/**
 * Shared TypeScript types mirroring the backend's Mongoose schemas.
 * Keeping these in one file makes it easy to keep frontend/backend
 * contracts in sync as the API evolves.
 */

export interface User {
  id: string;
  name: string;
  email: string;
  organization?: string;
  role: 'user' | 'admin';
  avatarColor: string;
  preferences: {
    theme: 'light' | 'dark';
    emailAlerts: boolean;
  };
  createdAt: string;
}

export type FileType = 'pdf' | 'docx' | 'jpg' | 'jpeg' | 'png';
export type DocumentStatus = 'uploaded' | 'processing' | 'analyzed' | 'failed';

export interface DocumentRecord {
  id: string;
  originalName: string;
  fileType: FileType;
  fileSizeBytes: number;
  status: DocumentStatus;
  createdAt: string;
}

export type Severity = 'info' | 'low' | 'medium' | 'high';
export type RiskLevel = 'Low' | 'Medium' | 'High';

export interface Finding {
  category: 'metadata' | 'ocr' | 'tampering' | 'signature' | 'qr' | 'duplicate';
  severity: Severity;
  title: string;
  description: string;
}

export interface SuspiciousSection {
  page: number;
  excerpt: string;
  reason: string;
}

export interface Report {
  _id: string;
  user: string;
  document: string;
  fileName: string;
  authenticityScore: number;
  riskLevel: RiskLevel;
  summary: string;
  findings: Finding[];
  suspiciousSections: SuspiciousSection[];
  modules: Record<string, unknown>;
  aiProvider: string;
  createdAt: string;
}

export interface DashboardStats {
  total: number;
  avgScore: number;
  riskCounts: { Low: number; Medium: number; High: number };
  trend: { date: string; score: number }[];
}
