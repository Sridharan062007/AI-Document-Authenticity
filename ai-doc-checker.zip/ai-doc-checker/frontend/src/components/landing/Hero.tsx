import { Link } from 'react-router-dom';
import { ArrowRight, ScanLine } from 'lucide-react';
import ScoreGauge from '../ui/ScoreGauge';

export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 px-6 py-20 md:grid-cols-2 md:py-28">
        <div className="animate-fade-up">
          <span className="label-eyebrow">Document forensics, automated</span>
          <h1 className="mt-4 font-display text-4xl font-semibold leading-[1.1] tracking-tight text-ink dark:text-paper sm:text-5xl">
            Know if a document is real before you rely on it.
          </h1>
          <p className="mt-5 max-w-lg text-base leading-relaxed text-ink/65 dark:text-paper/65">
            Veridoc examines metadata, embedded text, compression artifacts, digital
            signatures, and QR codes to flag manipulated documents — and hands you a
            clear authenticity score, not just a verdict.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link to="/signup" className="btn-primary">
              Verify your first document <ArrowRight size={16} />
            </Link>
            <a href="#how-it-works" className="btn-secondary">
              See how it works
            </a>
          </div>
          <div className="mt-10 flex items-center gap-6 text-xs text-ink/45 dark:text-paper/45">
            <span>PDF</span>
            <span className="h-1 w-1 rounded-full bg-ink/20 dark:bg-paper/20" />
            <span>DOCX</span>
            <span className="h-1 w-1 rounded-full bg-ink/20 dark:bg-paper/20" />
            <span>JPG / PNG</span>
          </div>
        </div>

        <div className="relative flex justify-center">
          <div className="relative w-full max-w-sm rounded-3xl border border-ink/8 dark:border-paper/10 bg-white dark:bg-ink-light p-8 shadow-card-hover">
            <div className="absolute inset-x-8 top-0 h-px overflow-hidden">
              <div className="h-24 w-full bg-gradient-to-b from-verified/25 to-transparent animate-scan" />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-medium text-ink/50 dark:text-paper/50">
                <ScanLine size={14} className="text-verified" />
                Scanning report.pdf
              </div>
              <span className="rounded-full bg-verified/10 px-2 py-0.5 text-[11px] font-semibold text-verified-dark dark:text-verified">
                Complete
              </span>
            </div>
            <div className="mt-6 flex justify-center">
              <ScoreGauge score={94} riskLevel="Low" size={160} />
            </div>
            <div className="mt-6 space-y-2 text-xs text-ink/55 dark:text-paper/55">
              <div className="flex items-center justify-between">
                <span>Metadata consistency</span>
                <span className="font-medium text-verified">Passed</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Compression analysis</span>
                <span className="font-medium text-verified">Passed</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Digital signature</span>
                <span className="font-medium text-ink/40 dark:text-paper/40">Not present</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
