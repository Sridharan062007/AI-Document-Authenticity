import { UploadCloud, ScanSearch, FileCheck2 } from 'lucide-react';

const STEPS = [
  { icon: UploadCloud, title: 'Upload', description: 'Drag in a PDF, DOCX, JPG, or PNG. Files stay local to your analysis session.' },
  { icon: ScanSearch, title: 'Analyze', description: 'Six modules run in parallel: metadata, OCR, tamper detection, signatures, QR codes, and duplicates.' },
  { icon: FileCheck2, title: 'Review', description: 'Get a 0-100 authenticity score, a risk level, and a downloadable report you can share.' },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="bg-ink/[0.02] dark:bg-paper/[0.03] py-24">
      <div className="mx-auto max-w-7xl px-6">
        <span className="label-eyebrow">The process</span>
        <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl">From upload to verdict in seconds.</h2>

        <div className="mt-14 grid grid-cols-1 gap-10 md:grid-cols-3">
          {STEPS.map(({ icon: Icon, title, description }, i) => (
            <div key={title} className="relative">
              <div className="flex items-center gap-3">
                <span className="font-display text-sm text-ink/30 dark:text-paper/30">0{i + 1}</span>
                <div className="h-px flex-1 bg-ink/10 dark:bg-paper/10" />
              </div>
              <div className="mt-4 flex h-11 w-11 items-center justify-center rounded-xl bg-ink dark:bg-verified text-paper dark:text-ink">
                <Icon size={18} />
              </div>
              <h3 className="mt-4 font-display text-xl font-semibold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink/60 dark:text-paper/60">{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
