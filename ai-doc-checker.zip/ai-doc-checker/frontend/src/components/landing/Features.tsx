import { FileSearch, ScanText, Fingerprint, QrCode, Copy, FileBarChart } from 'lucide-react';

const FEATURES = [
  {
    icon: FileSearch,
    title: 'Metadata analysis',
    description: 'Reads creation and modification timestamps, author, and producing software to spot inconsistencies.',
  },
  {
    icon: ScanText,
    title: 'OCR text extraction',
    description: 'Pulls text from scanned images and PDFs, then checks it for irregular spacing and low-confidence regions.',
  },
  {
    icon: Fingerprint,
    title: 'Tamper detection',
    description: 'Error-level analysis surfaces regions that were edited, pasted, or re-compressed separately from the rest of the file.',
  },
  {
    icon: FileBarChart,
    title: 'Digital signature checks',
    description: 'Detects embedded signature fields and validates document structure around them.',
  },
  {
    icon: QrCode,
    title: 'QR & barcode verification',
    description: 'Decodes embedded QR codes and barcodes so their payloads can be reviewed or cross-checked.',
  },
  {
    icon: Copy,
    title: 'Duplicate detection',
    description: 'Flags byte-identical re-uploads and near-duplicate content from previously verified documents.',
  },
];

export default function Features() {
  return (
    <section id="features" className="mx-auto max-w-7xl px-6 py-24">
      <div className="max-w-xl">
        <span className="label-eyebrow">What gets checked</span>
        <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight sm:text-4xl">
          Six independent checks, one clear score.
        </h2>
        <p className="mt-4 text-ink/65 dark:text-paper/65">
          Every module runs independently and contributes to a single authenticity
          score, so you see exactly which signal raised or lowered your document's rating.
        </p>
      </div>

      <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map(({ icon: Icon, title, description }) => (
          <div key={title} className="card p-6 transition-shadow hover:shadow-card-hover">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-verified/10 text-verified-dark dark:text-verified">
              <Icon size={18} />
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold">{title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-ink/60 dark:text-paper/60">{description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
