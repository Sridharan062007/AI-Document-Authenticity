import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { UploadCloud, FileText, Image as ImageIcon, X } from 'lucide-react';

const ACCEPTED = {
  'application/pdf': ['.pdf'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png'],
};

function fileIcon(file: File) {
  if (file.type.startsWith('image/')) return <ImageIcon size={20} />;
  return <FileText size={20} />;
}

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function Dropzone({ onFileSelected }: { onFileSelected: (file: File) => void }) {
  const [selected, setSelected] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback(
    (acceptedFiles: File[], rejectedFiles: { errors: { message: string }[] }[]) => {
      setError(null);
      if (rejectedFiles.length > 0) {
        setError(rejectedFiles[0].errors[0]?.message || 'File not accepted');
        return;
      }
      const file = acceptedFiles[0];
      if (file) {
        setSelected(file);
        onFileSelected(file);
      }
    },
    [onFileSelected]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED,
    maxFiles: 1,
    maxSize: 15 * 1024 * 1024,
  });

  const clear = () => {
    setSelected(null);
    setError(null);
  };

  if (selected) {
    return (
      <div className="card flex items-center justify-between p-5">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-verified/10 text-verified-dark dark:text-verified">
            {fileIcon(selected)}
          </div>
          <div>
            <p className="text-sm font-medium">{selected.name}</p>
            <p className="text-xs text-ink/50 dark:text-paper/50">{formatSize(selected.size)}</p>
          </div>
        </div>
        <button onClick={clear} className="text-ink/40 hover:text-ink dark:text-paper/40 dark:hover:text-paper" aria-label="Remove file">
          <X size={18} />
        </button>
      </div>
    );
  }

  return (
    <div>
      <div
        {...getRootProps()}
        className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-12 text-center transition-colors ${
          isDragActive ? 'border-verified bg-verified/5' : 'border-ink/15 dark:border-paper/15 hover:border-verified/60'
        }`}
      >
        <input {...getInputProps()} aria-label="Upload document" />
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-ink/5 dark:bg-paper/10">
          <UploadCloud size={24} className="text-ink/50 dark:text-paper/50" />
        </div>
        <p className="mt-4 text-sm font-medium">
          {isDragActive ? 'Drop the document here' : 'Drag and drop a document, or click to browse'}
        </p>
        <p className="mt-1 text-xs text-ink/45 dark:text-paper/45">PDF, DOCX, JPG, JPEG, or PNG — up to 15MB</p>
      </div>
      {error && <p className="mt-2 text-sm text-risk-high">{error}</p>}
    </div>
  );
}
