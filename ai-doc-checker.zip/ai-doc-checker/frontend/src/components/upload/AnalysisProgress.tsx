import { useEffect, useState } from 'react';
import { CheckCircle2, Loader2 } from 'lucide-react';

const STAGES = [
  'Uploading document',
  'Extracting metadata',
  'Running OCR text extraction',
  'Checking for tampering',
  'Verifying signatures & QR codes',
  'Calculating authenticity score',
];

/**
 * Purely presentational staged-progress indicator. The actual analysis call
 * is a single request, but stepping through these stages gives the user
 * meaningful feedback about what's happening rather than a static spinner.
 */
export default function AnalysisProgress({ complete }: { complete: boolean }) {
  const [activeStage, setActiveStage] = useState(0);

  useEffect(() => {
    if (complete) {
      setActiveStage(STAGES.length);
      return;
    }
    const interval = setInterval(() => {
      setActiveStage((prev) => (prev < STAGES.length - 1 ? prev + 1 : prev));
    }, 900);
    return () => clearInterval(interval);
  }, [complete]);

  return (
    <div className="card p-6">
      <ul className="space-y-4">
        {STAGES.map((stage, i) => {
          const done = i < activeStage;
          const active = i === activeStage && !complete;
          return (
            <li key={stage} className="flex items-center gap-3 text-sm">
              {done ? (
                <CheckCircle2 size={18} className="text-verified shrink-0" />
              ) : active ? (
                <Loader2 size={18} className="animate-spin text-verified shrink-0" />
              ) : (
                <span className="h-[18px] w-[18px] shrink-0 rounded-full border-2 border-ink/15 dark:border-paper/15" />
              )}
              <span className={done || active ? 'text-ink dark:text-paper' : 'text-ink/40 dark:text-paper/40'}>{stage}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
