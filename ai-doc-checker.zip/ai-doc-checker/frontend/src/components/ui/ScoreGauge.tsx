/**
 * ScoreGauge.tsx
 * The page's signature visual element: a circular "verification seal" that
 * fills in like a wax stamp being pressed as the authenticity score loads,
 * tying the abstract 0-100 number back to the idea of an official seal of
 * approval (or a fractured one, for risky documents).
 */
import { useEffect, useState } from 'react';
import type { RiskLevel } from '../../types';

const RISK_COLOR: Record<RiskLevel, string> = {
  Low: '#0F9D6B',
  Medium: '#D97706',
  High: '#DC2626',
};

export default function ScoreGauge({
  score,
  riskLevel,
  size = 180,
  animate = true,
}: {
  score: number;
  riskLevel: RiskLevel;
  size?: number;
  animate?: boolean;
}) {
  const [displayScore, setDisplayScore] = useState(animate ? 0 : score);
  const radius = (size - 20) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (displayScore / 100) * circumference;
  const color = RISK_COLOR[riskLevel];

  useEffect(() => {
    if (!animate) return;
    let frame: number;
    const start = performance.now();
    const duration = 1200;
    const step = (now: number) => {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayScore(Math.round(eased * score));
      if (progress < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [score, animate]);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="currentColor" strokeWidth={10} className="text-ink/5 dark:text-paper/10" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={10}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: animate ? 'none' : 'stroke-dashoffset 0.6s ease' }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="font-display text-4xl font-semibold" style={{ color }}>
          {displayScore}
        </span>
        <span className="text-[11px] uppercase tracking-wider text-ink/50 dark:text-paper/50">out of 100</span>
      </div>
    </div>
  );
}
