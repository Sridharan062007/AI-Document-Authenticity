import type { RiskLevel } from '../../types';
import { ShieldCheck, ShieldAlert, ShieldX } from 'lucide-react';

const CONFIG: Record<RiskLevel, { bg: string; text: string; icon: JSX.Element; label: string }> = {
  Low: {
    bg: 'bg-verified/10',
    text: 'text-verified-dark dark:text-verified',
    icon: <ShieldCheck size={14} />,
    label: 'Low risk',
  },
  Medium: {
    bg: 'bg-risk-medium/10',
    text: 'text-risk-medium',
    icon: <ShieldAlert size={14} />,
    label: 'Medium risk',
  },
  High: {
    bg: 'bg-risk-high/10',
    text: 'text-risk-high',
    icon: <ShieldX size={14} />,
    label: 'High risk',
  },
};

export default function RiskBadge({ level }: { level: RiskLevel }) {
  const cfg = CONFIG[level];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${cfg.bg} ${cfg.text}`}>
      {cfg.icon}
      {cfg.label}
    </span>
  );
}
