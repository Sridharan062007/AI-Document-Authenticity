import { Link } from 'react-router-dom';
import { FileText, ChevronRight } from 'lucide-react';
import RiskBadge from '../ui/RiskBadge';
import type { Report } from '../../types';

export default function ReportCard({ report }: { report: Report }) {
  return (
    <Link
      to={`/reports/${report._id}`}
      className="card flex items-center justify-between gap-4 p-5 transition-shadow hover:shadow-card-hover"
    >
      <div className="flex min-w-0 items-center gap-4">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-ink/5 dark:bg-paper/10">
          <FileText size={18} />
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{report.fileName}</p>
          <p className="text-xs text-ink/45 dark:text-paper/45">{new Date(report.createdAt).toLocaleString()}</p>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-4">
        <span className="font-display text-lg font-semibold">{report.authenticityScore}</span>
        <RiskBadge level={report.riskLevel} />
        <ChevronRight size={16} className="text-ink/30 dark:text-paper/30" />
      </div>
    </Link>
  );
}
