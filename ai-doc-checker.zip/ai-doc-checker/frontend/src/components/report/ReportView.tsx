import { Download, AlertTriangle, Info, ShieldAlert, ShieldX } from 'lucide-react';
import type { Report, Severity } from '../../types';
import ScoreGauge from '../ui/ScoreGauge';
import RiskBadge from '../ui/RiskBadge';
import Button from '../ui/Button';
import api from '../../services/api';

const SEVERITY_ICON: Record<Severity, JSX.Element> = {
  info: <Info size={16} className="text-accent" />,
  low: <Info size={16} className="text-verified" />,
  medium: <ShieldAlert size={16} className="text-risk-medium" />,
  high: <ShieldX size={16} className="text-risk-high" />,
};

const SEVERITY_ORDER: Record<Severity, number> = { high: 0, medium: 1, low: 2, info: 3 };

export default function ReportView({ report }: { report: Report }) {
  const handleDownload = async () => {
    const response = await api.get(`/reports/${report._id}/pdf`, { responseType: 'blob' });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `authenticity-report-${report._id}.pdf`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const sortedFindings = [...report.findings].sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]);

  return (
    <div className="space-y-8">
      <div className="card flex flex-col items-center gap-6 p-8 text-center sm:flex-row sm:text-left">
        <ScoreGauge score={report.authenticityScore} riskLevel={report.riskLevel} />
        <div className="flex-1">
          <p className="truncate text-sm font-medium text-ink/50 dark:text-paper/50">{report.fileName}</p>
          <div className="mt-2 flex flex-wrap items-center justify-center gap-3 sm:justify-start">
            <RiskBadge level={report.riskLevel} />
            <span className="text-xs text-ink/40 dark:text-paper/40">
              Analyzed {new Date(report.createdAt).toLocaleString()}
            </span>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-ink/70 dark:text-paper/70">{report.summary}</p>
          <Button onClick={handleDownload} variant="secondary" className="mt-5">
            <Download size={16} /> Download PDF report
          </Button>
        </div>
      </div>

      {report.suspiciousSections.length > 0 && (
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-display text-lg font-semibold">
            <AlertTriangle size={18} className="text-risk-medium" /> Suspicious sections
          </h3>
          <div className="mt-4 space-y-3">
            {report.suspiciousSections.map((s, i) => (
              <div key={i} className="rounded-xl border border-risk-medium/20 bg-risk-medium/5 p-4">
                <p className="text-sm font-medium">{s.excerpt}</p>
                <p className="mt-1 text-xs text-ink/60 dark:text-paper/60">{s.reason}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="card p-6">
        <h3 className="font-display text-lg font-semibold">Detailed findings</h3>
        <div className="mt-4 divide-y divide-ink/8 dark:divide-paper/10">
          {sortedFindings.map((f, i) => (
            <div key={i} className="flex gap-3 py-4 first:pt-0 last:pb-0">
              <div className="mt-0.5 shrink-0">{SEVERITY_ICON[f.severity]}</div>
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium">{f.title}</p>
                  <span className="rounded-full bg-ink/5 dark:bg-paper/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-ink/50 dark:text-paper/50">
                    {f.category}
                  </span>
                </div>
                <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
