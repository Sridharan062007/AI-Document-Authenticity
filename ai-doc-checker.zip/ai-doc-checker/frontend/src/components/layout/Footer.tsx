import { ShieldCheck } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-ink/8 dark:border-paper/10 py-10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 text-sm text-ink/50 dark:text-paper/50 sm:flex-row">
        <div className="flex items-center gap-2 font-display font-semibold text-ink dark:text-paper">
          <ShieldCheck size={16} className="text-verified" />
          Veridoc
        </div>
        <p>Built as a final-year engineering project. Not a substitute for formal forensic examination.</p>
        <p>&copy; {new Date().getFullYear()} Veridoc</p>
      </div>
    </footer>
  );
}
