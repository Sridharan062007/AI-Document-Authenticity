import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { ShieldCheck, Menu, X, LogOut, LayoutDashboard, UploadCloud, History, User as UserIcon } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import ThemeToggle from '../ui/ThemeToggle';

const navLinkClass = ({ isActive }: { isActive: boolean }) =>
  `text-sm font-medium transition-colors ${isActive ? 'text-verified' : 'text-ink/70 dark:text-paper/70 hover:text-ink dark:hover:text-paper'}`;

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 border-b border-ink/8 dark:border-paper/10 bg-paper/85 dark:bg-ink/85 backdrop-blur-md">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-ink dark:bg-verified text-paper dark:text-ink">
            <ShieldCheck size={18} />
          </span>
          Veridoc
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          {user ? (
            <>
              <NavLink to="/dashboard" className={navLinkClass}>Dashboard</NavLink>
              <NavLink to="/upload" className={navLinkClass}>Verify a document</NavLink>
              <NavLink to="/history" className={navLinkClass}>History</NavLink>
            </>
          ) : (
            <>
              <a href="/#features" className="text-sm font-medium text-ink/70 dark:text-paper/70 hover:text-ink dark:hover:text-paper">Features</a>
              <a href="/#how-it-works" className="text-sm font-medium text-ink/70 dark:text-paper/70 hover:text-ink dark:hover:text-paper">How it works</a>
            </>
          )}
        </div>

        <div className="hidden items-center gap-3 md:flex">
          <ThemeToggle />
          {user ? (
            <>
              <NavLink to="/profile" className="flex h-9 w-9 items-center justify-center rounded-full text-xs font-semibold text-white" style={{ backgroundColor: user.avatarColor }}>
                {user.name.charAt(0).toUpperCase()}
              </NavLink>
              <button onClick={handleLogout} className="btn-secondary !px-3 !py-2" aria-label="Log out">
                <LogOut size={16} />
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium text-ink/70 dark:text-paper/70 hover:text-ink dark:hover:text-paper">Log in</Link>
              <Link to="/signup" className="btn-primary !px-4 !py-2.5">Get started</Link>
            </>
          )}
        </div>

        <button className="md:hidden" onClick={() => setMobileOpen((o) => !o)} aria-label="Toggle menu">
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {mobileOpen && (
        <div className="border-t border-ink/8 dark:border-paper/10 px-6 py-4 md:hidden">
          <div className="flex flex-col gap-4">
            {user ? (
              <>
                <Link onClick={() => setMobileOpen(false)} to="/dashboard" className="flex items-center gap-2 text-sm font-medium"><LayoutDashboard size={16} /> Dashboard</Link>
                <Link onClick={() => setMobileOpen(false)} to="/upload" className="flex items-center gap-2 text-sm font-medium"><UploadCloud size={16} /> Verify a document</Link>
                <Link onClick={() => setMobileOpen(false)} to="/history" className="flex items-center gap-2 text-sm font-medium"><History size={16} /> History</Link>
                <Link onClick={() => setMobileOpen(false)} to="/profile" className="flex items-center gap-2 text-sm font-medium"><UserIcon size={16} /> Profile</Link>
                <button onClick={handleLogout} className="flex items-center gap-2 text-sm font-medium text-risk-high"><LogOut size={16} /> Log out</button>
              </>
            ) : (
              <>
                <Link onClick={() => setMobileOpen(false)} to="/login" className="text-sm font-medium">Log in</Link>
                <Link onClick={() => setMobileOpen(false)} to="/signup" className="btn-primary w-full justify-center">Get started</Link>
              </>
            )}
            <div className="pt-2"><ThemeToggle /></div>
          </div>
        </div>
      )}
    </header>
  );
}
