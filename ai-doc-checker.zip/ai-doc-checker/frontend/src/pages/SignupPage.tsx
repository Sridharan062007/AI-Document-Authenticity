import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import Button from '../components/ui/Button';

export default function SignupPage() {
  const { signup } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    try {
      await signup(name, email, password, organization);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Unable to create account. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-md flex-col justify-center px-6 py-16">
      <div className="mb-8 flex flex-col items-center text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink dark:bg-verified text-paper dark:text-ink">
          <ShieldCheck size={22} />
        </span>
        <h1 className="mt-4 font-display text-2xl font-semibold">Create your account</h1>
        <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">Start verifying documents in under a minute.</p>
      </div>

      <form onSubmit={handleSubmit} className="card space-y-4 p-6">
        {error && <p className="rounded-lg bg-risk-high/10 px-3 py-2 text-sm text-risk-high">{error}</p>}
        <div>
          <label htmlFor="name" className="mb-1.5 block text-xs font-medium text-ink/60 dark:text-paper/60">Full name</label>
          <input id="name" type="text" required value={name} onChange={(e) => setName(e.target.value)} className="input-field" placeholder="Jordan Rivera" autoComplete="name" />
        </div>
        <div>
          <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-ink/60 dark:text-paper/60">Email</label>
          <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input-field" placeholder="you@example.com" autoComplete="email" />
        </div>
        <div>
          <label htmlFor="organization" className="mb-1.5 block text-xs font-medium text-ink/60 dark:text-paper/60">Organization (optional)</label>
          <input id="organization" type="text" value={organization} onChange={(e) => setOrganization(e.target.value)} className="input-field" placeholder="University, company, etc." />
        </div>
        <div>
          <label htmlFor="password" className="mb-1.5 block text-xs font-medium text-ink/60 dark:text-paper/60">Password</label>
          <input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="input-field" placeholder="At least 6 characters" autoComplete="new-password" />
        </div>
        <Button type="submit" loading={loading} className="w-full">Create account</Button>
      </form>

      <p className="mt-6 text-center text-sm text-ink/60 dark:text-paper/60">
        Already have an account? <Link to="/login" className="font-medium text-verified">Log in</Link>
      </p>
    </div>
  );
}
