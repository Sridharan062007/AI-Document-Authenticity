import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import api from '../services/api';

export default function ProfilePage() {
  const { user, updateUser } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [organization, setOrganization] = useState(user?.organization || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  if (!user) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    try {
      const { data } = await api.put('/auth/me', { name, organization });
      updateUser(data.user);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="font-display text-2xl font-semibold sm:text-3xl">Your profile</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">Manage your personal details.</p>

      <Card className="mt-8">
        <div className="flex items-center gap-4">
          <span
            className="flex h-16 w-16 items-center justify-center rounded-full text-xl font-semibold text-white"
            style={{ backgroundColor: user.avatarColor }}
          >
            {user.name.charAt(0).toUpperCase()}
          </span>
          <div>
            <p className="font-medium">{user.name}</p>
            <p className="text-sm text-ink/50 dark:text-paper/50">{user.email}</p>
          </div>
        </div>

        <form onSubmit={handleSave} className="mt-8 space-y-4">
          <div>
            <label htmlFor="name" className="mb-1.5 block text-xs font-medium text-ink/60 dark:text-paper/60">Full name</label>
            <input id="name" className="input-field" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label htmlFor="org" className="mb-1.5 block text-xs font-medium text-ink/60 dark:text-paper/60">Organization</label>
            <input id="org" className="input-field" value={organization} onChange={(e) => setOrganization(e.target.value)} />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-ink/60 dark:text-paper/60">Email</label>
            <input className="input-field opacity-60" value={user.email} disabled />
          </div>
          <div className="flex items-center gap-3">
            <Button type="submit" loading={saving}>Save changes</Button>
            {saved && <span className="text-sm text-verified">Saved</span>}
          </div>
        </form>
      </Card>
    </div>
  );
}
