import { Link } from 'react-router-dom';
import { ShieldQuestion } from 'lucide-react';

export default function NotFoundPage() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-6 text-center">
      <ShieldQuestion size={40} className="text-ink/30 dark:text-paper/30" />
      <h1 className="mt-4 font-display text-2xl font-semibold">Page not found</h1>
      <p className="mt-2 text-sm text-ink/60 dark:text-paper/60">The page you're looking for doesn't exist.</p>
      <Link to="/" className="btn-primary mt-6">Back to home</Link>
    </div>
  );
}
