import Hero from '../components/landing/Hero';
import Features from '../components/landing/Features';
import HowItWorks from '../components/landing/HowItWorks';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function LandingPage() {
  return (
    <div>
      <Hero />
      <Features />
      <HowItWorks />
      <section className="mx-auto max-w-7xl px-6 py-24">
        <div className="card flex flex-col items-center gap-6 p-10 text-center sm:p-16">
          <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Ready to verify your first document?
          </h2>
          <p className="max-w-md text-ink/60 dark:text-paper/60">
            Free to try. No credit card required — just an account.
          </p>
          <Link to="/signup" className="btn-primary">
            Get started <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
}
