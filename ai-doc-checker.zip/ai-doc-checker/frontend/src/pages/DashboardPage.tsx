import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { UploadCloud, FileText, TrendingUp, ArrowRight } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import api from '../services/api';
import { useAuth } from '../hooks/useAuth';
import Card from '../components/ui/Card';
import ReportCard from '../components/report/ReportCard';
import Spinner from '../components/ui/Spinner';
import type { DashboardStats, Report } from '../types';

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [statsRes, reportsRes] = await Promise.all([
          api.get('/reports/stats/summary'),
          api.get('/reports?limit=5'),
        ]);
        setStats(statsRes.data.stats);
        setReports(reportsRes.data.reports);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Spinner size={28} />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="font-display text-2xl font-semibold sm:text-3xl">Welcome back, {user?.name.split(' ')[0]}</h1>
          <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">Here's a snapshot of your document verification activity.</p>
        </div>
        <Link to="/upload" className="btn-primary self-start">
          <UploadCloud size={16} /> Verify a document
        </Link>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
        <Card>
          <p className="text-xs font-medium uppercase tracking-wide text-ink/45 dark:text-paper/45">Documents analyzed</p>
          <p className="mt-2 font-display text-3xl font-semibold">{stats?.total ?? 0}</p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wide text-ink/45 dark:text-paper/45">Average authenticity score</p>
          <p className="mt-2 font-display text-3xl font-semibold">{stats?.avgScore ?? 0}</p>
        </Card>
        <Card>
          <p className="text-xs font-medium uppercase tracking-wide text-ink/45 dark:text-paper/45">Risk breakdown</p>
          <div className="mt-2 flex gap-3 text-sm">
            <span className="text-verified">{stats?.riskCounts.Low ?? 0} low</span>
            <span className="text-risk-medium">{stats?.riskCounts.Medium ?? 0} med</span>
            <span className="text-risk-high">{stats?.riskCounts.High ?? 0} high</span>
          </div>
        </Card>
      </div>

      {stats && stats.trend.length > 1 && (
        <Card className="mt-6">
          <div className="flex items-center gap-2 text-sm font-medium text-ink/70 dark:text-paper/70">
            <TrendingUp size={16} className="text-verified" /> Recent score trend
          </div>
          <div className="mt-4 h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={stats.trend.map((t) => ({ ...t, date: new Date(t.date).toLocaleDateString() }))}>
                <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="currentColor" opacity={0.4} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="currentColor" opacity={0.4} />
                <Tooltip contentStyle={{ borderRadius: 12, border: 'none', fontSize: 12 }} />
                <Line type="monotone" dataKey="score" stroke="#0F9D6B" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}

      <div className="mt-10">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-semibold">Recent reports</h2>
          <Link to="/history" className="flex items-center gap-1 text-sm font-medium text-verified">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <div className="mt-4 space-y-3">
          {reports.length === 0 ? (
            <Card className="flex flex-col items-center gap-3 py-12 text-center">
              <FileText size={28} className="text-ink/30 dark:text-paper/30" />
              <p className="text-sm text-ink/60 dark:text-paper/60">No documents verified yet.</p>
              <Link to="/upload" className="btn-primary">Verify your first document</Link>
            </Card>
          ) : (
            reports.map((r) => <ReportCard key={r._id} report={r} />)
          )}
        </div>
      </div>
    </div>
  );
}
