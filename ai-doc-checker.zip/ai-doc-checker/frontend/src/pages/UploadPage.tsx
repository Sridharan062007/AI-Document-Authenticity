import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Dropzone from '../components/upload/Dropzone';
import AnalysisProgress from '../components/upload/AnalysisProgress';
import Button from '../components/ui/Button';
import ProgressBar from '../components/ui/ProgressBar';
import api from '../services/api';

type Stage = 'idle' | 'uploading' | 'analyzing' | 'done' | 'error';

export default function UploadPage() {
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [stage, setStage] = useState<Stage>('idle');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!file) return;
    setError(null);
    setStage('uploading');
    setUploadProgress(0);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const uploadRes = await api.post('/documents/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (evt) => {
          if (evt.total) setUploadProgress(Math.round((evt.loaded / evt.total) * 100));
        },
      });

      const documentId = uploadRes.data.document.id;
      setStage('analyzing');

      const analyzeRes = await api.post(`/documents/${documentId}/analyze`);
      setStage('done');

      setTimeout(() => navigate(`/reports/${analyzeRes.data.report._id}`), 600);
    } catch (err: any) {
      setStage('error');
      setError(err.response?.data?.message || 'Something went wrong during analysis. Please try again.');
    }
  };

  return (
    <div className="mx-auto max-w-2xl px-6 py-14">
      <div className="mb-8 text-center">
        <span className="label-eyebrow">New verification</span>
        <h1 className="mt-2 font-display text-2xl font-semibold sm:text-3xl">Upload a document to verify</h1>
        <p className="mt-2 text-sm text-ink/60 dark:text-paper/60">
          We'll run metadata, OCR, tamper, signature, QR, and duplicate checks automatically.
        </p>
      </div>

      {stage === 'idle' || stage === 'error' ? (
        <div className="space-y-6">
          <Dropzone onFileSelected={setFile} />
          {error && <p className="rounded-lg bg-risk-high/10 px-3 py-2 text-sm text-risk-high">{error}</p>}
          <Button onClick={handleAnalyze} disabled={!file} className="w-full">
            Analyze document
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          {stage === 'uploading' && <ProgressBar progress={uploadProgress} label="Uploading" />}
          <AnalysisProgress complete={stage === 'done'} />
        </div>
      )}
    </div>
  );
}
