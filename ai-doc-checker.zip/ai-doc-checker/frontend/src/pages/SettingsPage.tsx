import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useTheme } from '../hooks/useTheme';
import Card from '../components/ui/Card';
import api from '../services/api';

export default function SettingsPage() {
  const { user, updateUser } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [emailAlerts, setEmailAlerts] = useState(user?.preferences.emailAlerts ?? true);

  if (!user) return null;

  const handleToggleAlerts = async () => {
    const next = !emailAlerts;
    setEmailAlerts(next);
    const { data } = await api.put('/auth/me', { preferences: { emailAlerts: next } });
    updateUser(data.user);
  };

  return (
    <div className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="font-display text-2xl font-semibold sm:text-3xl">Settings</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">Customize your Veridoc experience.</p>

      <Card className="mt-8 divide-y divide-ink/8 dark:divide-paper/10">
        <div className="flex items-center justify-between py-4 first:pt-0">
          <div>
            <p className="text-sm font-medium">Appearance</p>
            <p className="text-xs text-ink/50 dark:text-paper/50">Switch between light and dark mode.</p>
          </div>
          <button onClick={toggleTheme} className="btn-secondary !py-2">
            {theme === 'light' ? 'Switch to dark' : 'Switch to light'}
          </button>
        </div>

        <div className="flex items-center justify-between py-4 last:pb-0">
          <div>
            <p className="text-sm font-medium">Email alerts</p>
            <p className="text-xs text-ink/50 dark:text-paper/50">Get notified when a high-risk document is detected.</p>
          </div>
          <button
            onClick={handleToggleAlerts}
            role="switch"
            aria-checked={emailAlerts}
            className={`relative h-6 w-11 rounded-full transition-colors ${emailAlerts ? 'bg-verified' : 'bg-ink/15 dark:bg-paper/15'}`}
          >
            <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${emailAlerts ? 'translate-x-5' : 'translate-x-0.5'}`} />
          </button>
        </div>
      </Card>
    </div>
  );
}
