import { useEffect, useState } from 'react';
import { Search, FileText } from 'lucide-react';
import api from '../services/api';
import ReportCard from '../components/report/ReportCard';
import Spinner from '../components/ui/Spinner';
import Card from '../components/ui/Card';
import type { Report, RiskLevel } from '../types';

const RISK_FILTERS: (RiskLevel | 'All')[] = ['All', 'Low', 'Medium', 'High'];

export default function HistoryPage() {
  const [reports, setReports] = useState<Report[]>([]);
  const [search, setSearch] = useState('');
  const [risk, setRisk] = useState<RiskLevel | 'All'>('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timeout = setTimeout(() => {
      const load = async () => {
        setLoading(true);
        try {
          const params: Record<string, string> = {};
          if (search) params.search = search;
          if (risk !== 'All') params.risk = risk;
          const { data } = await api.get('/reports', { params });
          setReports(data.reports);
        } finally {
          setLoading(false);
        }
      };
      load();
    }, 300); // debounce search input
    return () => clearTimeout(timeout);
  }, [search, risk]);

  return (
    <div className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="font-display text-2xl font-semibold sm:text-3xl">Verification history</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-paper/60">Search and filter every document you've verified.</p>

      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink/40 dark:text-paper/40" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by file name..."
            className="input-field pl-10"
            aria-label="Search reports"
          />
        </div>
        <div className="flex gap-2">
          {RISK_FILTERS.map((r) => (
            <button
              key={r}
              onClick={() => setRisk(r)}
              className={`rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors ${
                risk === r ? 'bg-ink dark:bg-verified text-paper dark:text-ink' : 'bg-ink/5 dark:bg-paper/10 text-ink/60 dark:text-paper/60'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 space-y-3">
        {loading ? (
          <div className="flex justify-center py-16"><Spinner size={24} /></div>
        ) : reports.length === 0 ? (
          <Card className="flex flex-col items-center gap-2 py-14 text-center">
            <FileText size={26} className="text-ink/30 dark:text-paper/30" />
            <p className="text-sm text-ink/60 dark:text-paper/60">No reports match your search.</p>
          </Card>
        ) : (
          reports.map((r) => <ReportCard key={r._id} report={r} />)
        )}
      </div>
    </div>
  );
}
