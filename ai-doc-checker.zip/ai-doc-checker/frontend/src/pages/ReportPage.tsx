import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import api from '../services/api';
import ReportView from '../components/report/ReportView';
import Spinner from '../components/ui/Spinner';
import type { Report } from '../types';

export default function ReportPage() {
  const { id } = useParams();
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await api.get(`/reports/${id}`);
        setReport(data.report);
      } catch (err: any) {
        setError(err.response?.data?.message || 'Report not found.');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Spinner size={28} />
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-20 text-center">
        <p className="text-sm text-risk-high">{error}</p>
        <Link to="/history" className="mt-4 inline-block text-sm font-medium text-verified">Back to history</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-12">
      <Link to="/history" className="mb-6 inline-flex items-center gap-1 text-sm font-medium text-ink/60 dark:text-paper/60 hover:text-ink dark:hover:text-paper">
        <ArrowLeft size={16} /> Back to history
      </Link>
      <ReportView report={report} />
    </div>
  );
}
